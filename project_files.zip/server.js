const express = require('express');
const http = require('http');
const path = require('path');
const os = require('os');
const QRCode = require('qrcode');
const XLSX = require('xlsx');
const multer = require('multer');
const { customAlphabet } = require('nanoid');
const { Server } = require('socket.io');
const crypto = require('crypto');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const db = require('./db');
const { SEED_LABS } = require('./labs-content');
const { SEED_DRAWING_TASKS } = require('./drawing-content');
const { SEED_ANSWER_KEYS } = require('./drawing-answer-keys-content');
const { computeAnswer: computeToleranceAnswer, SEED_TOLERANCE_TASK, RANGES: TOLERANCE_RANGES, HOLE_FIELDS, SHAFT_FIELDS, rangeIndex: toleranceRangeIndex } = require('./tolerance-content');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

const nanoid = customAlphabet('ABCDEFGHJKLMNPQRSTUVWXYZ23456789', 5);
const participantId = customAlphabet('abcdefghijklmnopqrstuvwxyz0123456789', 12);
const companyIdGen = customAlphabet('abcdefghijklmnopqrstuvwxyz0123456789', 12);

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

// ==================== КОНФИГУРАЦИЯ БЕЗОПАСНОСТИ И ТАРИФОВ ====================
// ВАЖНО: перед деплоем в продакшн задайте эти переменные окружения на хостинге (например, в Render → Environment):
//   ADMIN_PASSWORD       — ваш собственный пароль для входа в /admin
//   SESSION_SECRET       — любая длинная случайная строка (секрет для подписи токенов)
//   DEVELOPER_CONTACTS   — текст с вашими контактами, который увидят клиенты после окончания пробного периода
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin-change-me-2024';
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const DEVELOPER_CONTACTS = process.env.DEVELOPER_CONTACTS ||
  'Свяжитесь с разработчиком, чтобы продолжить работу (контакты не настроены — задайте переменную окружения DEVELOPER_CONTACTS).';

const FREE_MAX_TESTS = 3;
const FREE_MAX_QUESTIONS = 20;
const MAX_IMAGE_LEN = 1500000; // ~1.1 МБ бинарных данных в виде base64 data URL

// Проверяет изображение вопроса: допускается только data URL (картинка, отправленная
// с клиента уже сжатой через canvas), с ограничением на размер, чтобы не раздувать
// единый JSON-блок базы данных, который целиком перезаписывается при каждом сохранении.
function sanitizeQuestionImage(img) {
  if (!img || typeof img !== 'string') return null;
  if (!img.startsWith('data:image/')) return null;
  if (img.length > MAX_IMAGE_LEN) return null;
  return img;
}
const FREE_MAX_SUBMISSIONS = 20;

if (!process.env.ADMIN_PASSWORD) {
  console.warn('[security] ВНИМАНИЕ: ADMIN_PASSWORD не задан в переменных окружения — используется пароль по умолчанию. Задайте свой пароль перед выходом в продакшн!');
}
if (!process.env.SESSION_SECRET) {
  console.warn('[security] ВНИМАНИЕ: SESSION_SECRET не задан — сгенерирован случайный на время работы процесса (все токены станут недействительны при перезапуске сервера). Рекомендуется задать постоянный секрет в переменных окружения.');
}

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '3mb' }));
app.get(['/', '/index.html'], require('./defect-inject')); // вставка вкладки «Акты дефектации» в панель
app.use(express.static(path.join(__dirname, 'public')));

// Ограничение частоты запросов на чувствительные маршруты (защита от подбора паролей и злоупотреблений)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Слишком много попыток. Попробуйте снова через несколько минут.' }
});
const translateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Слишком много запросов на перевод. Подождите немного.' }
});
const joinLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Слишком много попыток присоединения с этой сети. Подождите немного.' }
});

// ==================== БЕЗОПАСНЫЙ ДОСТУП К ОБЪЕКТАМ ПО КЛЮЧУ ====================
// Защита от подмены ключа (например "__proto__"), который иначе мог бы вернуть
// Object.prototype вместо undefined и обмануть проверки на существование записи.
function safeGet(dict, key) {
  if (!dict || typeof key !== 'string' || !key) return undefined;
  if (!Object.prototype.hasOwnProperty.call(dict, key)) return undefined;
  return dict[key];
}

// ==================== ПОДПИСАННЫЕ ТОКЕНЫ (вместо передачи "голого" id компании) ====================
function base64url(buf) {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function signToken(payload, ttlMs) {
  const body = base64url(Buffer.from(JSON.stringify({ ...payload, exp: Date.now() + ttlMs })));
  const sig = base64url(crypto.createHmac('sha256', SESSION_SECRET).update(body).digest());
  return `${body}.${sig}`;
}
function verifyToken(token) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  const expectedSig = base64url(crypto.createHmac('sha256', SESSION_SECRET).update(body).digest());
  if (sig.length !== expectedSig.length) return null;
  try {
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) return null;
  } catch (e) {
    return null;
  }
  try {
    const data = JSON.parse(Buffer.from(body.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString());
    if (!data.exp || Date.now() > data.exp) return null;
    return data;
  } catch (e) {
    return null;
  }
}

function getLocalIp() {
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const iface of ifaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return 'localhost';
}

function getBaseUrl() {
  if (process.env.PUBLIC_URL) return process.env.PUBLIC_URL.replace(/\/$/, '');
  if (process.env.RENDER_EXTERNAL_URL) return process.env.RENDER_EXTERNAL_URL.replace(/\/$/, '');
  return `http://${getLocalIp()}:${PORT}`;
}

// ==================== B2B: АВТОРИЗАЦИЯ И ТАРИФЫ ====================

function hashPassword(password) {
  // Устаревшая схема — оставлена только для проверки паролей, созданных до обновления безопасности.
  return crypto.createHash('sha256').update(password).digest('hex');
}

function hashPasswordSecure(password, existingSalt) {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPasswordSecure(password, stored) {
  if (typeof stored !== 'string' || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  try {
    const check = crypto.scryptSync(password, salt, 64).toString('hex');
    const a = Buffer.from(hash, 'hex');
    const b = Buffer.from(check, 'hex');
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch (e) {
    return false;
  }
}

// ==================== ПЕРЕВОД (RU -> KK) ====================

// Основной провайдер — Yandex Cloud Translate. Ключ привязан к аккаунту, а не к
// исходящему IP сервера, поэтому не страдает от общих блокировок анонимного
// доступа, в которые упирается MyMemory на бесплатном тарифе Render (там IP
// общий для многих чужих проектов). Плюс: Yandex принимает целую пачку текстов
// ОДНИМ запросом, поэтому лимиты по скорости запросов почти не встречаются даже
// на больших тестах. Настраивается через переменные окружения
// YANDEX_TRANSLATE_API_KEY и YANDEX_FOLDER_ID (см. Yandex Cloud Console).
const YANDEX_TRANSLATE_API_KEY = process.env.YANDEX_TRANSLATE_API_KEY || '';
const YANDEX_FOLDER_ID = process.env.YANDEX_FOLDER_ID || '';
const USE_YANDEX = !!(YANDEX_TRANSLATE_API_KEY && YANDEX_FOLDER_ID);

// Резервный вариант, если ключ Yandex ещё не настроен — анонимный MyMemory.
// Необязательный email поднимает его дневной лимит (см. документацию MyMemory,
// параметр «de»), но всё равно остаётся подвержен общим блокировкам IP Render.
const MYMEMORY_EMAIL = process.env.MYMEMORY_EMAIL || '';

if (USE_YANDEX) {
  console.log('[translate] Провайдер перевода: Yandex Cloud Translate');
} else {
  console.warn('[translate] ВНИМАНИЕ: YANDEX_TRANSLATE_API_KEY/YANDEX_FOLDER_ID не заданы — используется анонимный MyMemory (менее надёжен на общем IP Render, может упираться в лимит запросов). Задайте переменные окружения, чтобы включить Yandex.');
}

function translationCacheKey(text, target) {
  return crypto.createHash('sha1').update(target + '::' + text).digest('hex');
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

// Переводит пачку текстов ОДНИМ запросом к Yandex Cloud Translate API.
async function translateBatchViaYandex(texts) {
  const resp = await fetch('https://translate.api.cloud.yandex.net/translate/v2/translate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Api-Key ${YANDEX_TRANSLATE_API_KEY}`
    },
    body: JSON.stringify({
      folderId: YANDEX_FOLDER_ID,
      texts,
      sourceLanguageCode: 'ru',
      targetLanguageCode: 'kk'
    }),
    signal: AbortSignal.timeout(15000)
  });
  if (!resp.ok) {
    const body = await resp.text().catch(() => '');
    throw new Error(`yandex translate http ${resp.status}: ${body.slice(0, 200)}`);
  }
  const json = await resp.json();
  if (!json || !Array.isArray(json.translations)) throw new Error('yandex translate: неожиданный формат ответа');
  return json.translations.map(t => (t && t.text) || '');
}

async function translateOneViaMyMemory(text, target, attempt = 0) {
  try {
    let url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=ru|${target}`;
    if (MYMEMORY_EMAIL) url += `&de=${encodeURIComponent(MYMEMORY_EMAIL)}`;
    const resp = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (resp.status === 429) {
      // Превышена скорость запросов (не дневной лимит — тот приходит как 200 с
      // текстовым предупреждением, см. ниже). Даём сервису «отдышаться» и пробуем
      // ещё раз один раз, прежде чем сдаться и вернуть оригинал.
      if (attempt < 1) {
        await sleep(1500);
        return translateOneViaMyMemory(text, target, attempt + 1);
      }
      console.warn('[translate] MyMemory: превышен лимит запросов в секунду (429), временно возвращаем оригинал');
      return text;
    }
    if (!resp.ok) throw new Error('translate http ' + resp.status);
    const json = await resp.json();
    const translated = json && json.responseData && json.responseData.translatedText
      ? json.responseData.translatedText
      : text;
    // Иногда сервис возвращает служебные сообщения об ошибках вместо перевода
    // (например, исчерпан дневной бесплатный лимит) — такое НЕ кэшируем выше по стеку.
    const looksLikeError = /MYMEMORY WARNING|INVALID|QUERY LENGTH LIMIT/i.test(translated);
    return looksLikeError ? text : translated;
  } catch (e) {
    console.error('[translate] Ошибка перевода (MyMemory):', e.message);
    return text; // при недоступности сервиса возвращаем оригинал, чтобы приложение не падало
  }
}

// Переводит список текстов, используя кэш и выбранного провайдера (Yandex, если
// настроен, иначе резервный MyMemory). Кэшируются только реально переведённые
// тексты — ошибки/лимиты никогда не кэшируются, чтобы не «замораживать» текст
// непереведённым навсегда после временного сбоя сервиса.
async function translateBatch(texts, target) {
  const data = db.load();
  const results = new Array(texts.length);
  const toTranslate = []; // { index, text, key }

  texts.forEach((text, i) => {
    const clean = (text || '').toString();
    if (!clean.trim()) { results[i] = clean; return; }
    const key = translationCacheKey(clean, target);
    if (data.translations[key]) { results[i] = data.translations[key]; return; }
    toTranslate.push({ index: i, text: clean, key });
  });

  if (toTranslate.length === 0) return results;

  if (USE_YANDEX) {
    const GROUP_SIZE = 100; // с запасом по лимитам Yandex на размер одного запроса
    for (let g = 0; g < toTranslate.length; g += GROUP_SIZE) {
      const group = toTranslate.slice(g, g + GROUP_SIZE);
      try {
        const translated = await translateBatchViaYandex(group.map(t => t.text));
        const updates = {};
        group.forEach((t, i) => {
          const finalText = translated[i] || t.text;
          results[t.index] = finalText;
          updates[t.key] = finalText;
        });
        await db.update((d) => { if (!d.translations) d.translations = {}; Object.assign(d.translations, updates); });
      } catch (e) {
        console.error('[translate] Ошибка перевода (Yandex):', e.message);
        group.forEach((t) => { results[t.index] = t.text; }); // не кэшируем — попробуем снова в следующий раз
      }
    }
    return results;
  }

  // Резервный вариант без ключа Yandex — старая логика через анонимный MyMemory
  // (медленнее и менее надёжно на общем IP Render).
  const CONCURRENCY = 2;
  const DELAY_MS = 150;
  let idx = 0;
  async function worker() {
    while (idx < toTranslate.length) {
      const i = idx++;
      const t = toTranslate[i];
      const translated = await translateOneViaMyMemory(t.text, target);
      results[t.index] = translated;
      if (translated !== t.text) {
        await db.update((d) => { if (!d.translations) d.translations = {}; d.translations[t.key] = translated; });
      }
      if (idx < toTranslate.length) await sleep(DELAY_MS);
    }
  }
  const workers = [];
  for (let w = 0; w < CONCURRENCY; w++) workers.push(worker());
  await Promise.all(workers);
  return results;
}

app.post('/api/translate', translateLimiter, async (req, res) => {
  const { texts, target } = req.body;
  if (!Array.isArray(texts)) return res.status(400).json({ error: 'texts должен быть массивом' });
  const targetLang = target === 'kk' ? 'kk' : null;
  if (!targetLang) return res.status(400).json({ error: 'Поддерживается только target=kk' });
  if (texts.length === 0) return res.json({ translations: [] });
  if (texts.length > 300) return res.status(400).json({ error: 'Слишком много строк за один запрос' });
  try {
    const translations = await translateBatch(texts, targetLang);
    res.json({ translations });
  } catch (e) {
    res.status(500).json({ error: 'Ошибка сервиса перевода' });
  }
});

function checkAuth(req, res, next) {
  const token = req.headers['x-company-id'] || req.query.companyId;
  const payload = verifyToken(token);
  if (!payload || !payload.companyId) {
    return res.status(401).json({ error: 'Не авторизован' });
  }
  const data = db.load();
  const company = safeGet(data.companies, payload.companyId);
  if (!company) {
    return res.status(401).json({ error: 'Компания не найдена' });
  }
  if (company.blocked) {
    return res.status(403).json({ error: 'BLOCKED', message: 'Доступ заблокирован администратором. ' + DEVELOPER_CONTACTS });
  }
  if (company.plan === 'free' && (company.usage && company.usage.submissions || 0) >= FREE_MAX_SUBMISSIONS) {
    return res.status(403).json({
      error: 'TRIAL_ENDED',
      message: `Пробный период завершён: достигнут лимит ${FREE_MAX_SUBMISSIONS} прохождений тестов. ${DEVELOPER_CONTACTS}`
    });
  }
  req.company = company;
  req.companyId = payload.companyId;
  next();
}

function checkAdmin(req, res, next) {
  const token = req.headers['x-admin-token'];
  const payload = verifyToken(token);
  if (!payload || payload.role !== 'admin') {
    return res.status(401).json({ error: 'Требуется вход администратора' });
  }
  next();
}

// Проверка лимита компании до того, как студент присоединится/сдаст тест (публичные маршруты)
function trialBlockedForCompany(data, companyId) {
  const company = safeGet(data.companies, companyId);
  if (!company) return null;
  if (company.blocked) {
    return 'Доступ к этому тесту временно закрыт. ' + DEVELOPER_CONTACTS;
  }
  if (company.plan === 'free' && (company.usage && company.usage.submissions || 0) >= FREE_MAX_SUBMISSIONS) {
    return `Пробный период организатора теста завершён. ${DEVELOPER_CONTACTS}`;
  }
  return null;
}

async function incrementSubmissions(companyId) {
  await db.update((d) => {
    const c = safeGet(d.companies, companyId);
    if (c) {
      if (!c.usage) c.usage = { submissions: 0 };
      c.usage.submissions = (c.usage.submissions || 0) + 1;
    }
  });
}

// ==================== РЕГИСТРАЦИЯ / ВХОД ====================

app.post('/api/register', authLimiter, async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || !email.trim() || !password.trim()) {
    return res.status(400).json({ error: 'Заполните email и пароль' });
  }
  const cleanEmail = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
    return res.status(400).json({ error: 'Некорректный формат email' });
  }
  if (password.trim().length < 6) {
    return res.status(400).json({ error: 'Пароль должен быть не короче 6 символов' });
  }
  const data = db.load();
  const existing = Object.values(data.companies).find(c => c.email === cleanEmail);
  if (existing) {
    return res.status(400).json({ error: 'Эта почта уже зарегистрирована' });
  }
  const id = companyIdGen();
  const passwordHash = hashPasswordSecure(password.trim());
  const company = {
    id,
    email: cleanEmail,
    name: name ? name.trim().slice(0, 120) : 'Моя компания',
    passwordHash,
    plan: 'free',
    blocked: false,
    usage: { submissions: 0 },
    registeredAt: Date.now()
  };
  await db.update((d) => { d.companies[id] = company; });
  const token = signToken({ companyId: id }, 30 * 24 * 60 * 60 * 1000);
  res.json({ ok: true, companyId: id, token, email: cleanEmail, plan: 'free' });
});

app.post('/api/login', authLimiter, async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password || !email.trim() || !password.trim()) {
    return res.status(400).json({ error: 'Заполните email и пароль' });
  }
  const cleanEmail = email.trim().toLowerCase();
  const data = db.load();
  const company = Object.values(data.companies).find(c => c.email === cleanEmail);
  if (!company) {
    return res.status(401).json({ error: 'Неверная почта или пароль' });
  }
  let ok = verifyPasswordSecure(password.trim(), company.passwordHash);
  if (!ok && hashPassword(password.trim()) === company.passwordHash) {
    // Аккаунт создан до обновления безопасности — принимаем старый хеш и обновляем на новый.
    ok = true;
    await db.update((d) => {
      const c = safeGet(d.companies, company.id);
      if (c) c.passwordHash = hashPasswordSecure(password.trim());
    });
  }
  if (!ok) {
    return res.status(401).json({ error: 'Неверная почта или пароль' });
  }
  if (company.blocked) {
    return res.status(403).json({ error: 'BLOCKED', message: 'Доступ заблокирован администратором. ' + DEVELOPER_CONTACTS });
  }
  const token = signToken({ companyId: company.id }, 30 * 24 * 60 * 60 * 1000);
  res.json({ ok: true, companyId: company.id, token, email: company.email, plan: company.plan });
});

app.post('/api/admin/login', authLimiter, (req, res) => {
  const { password } = req.body;
  if (!password || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'Неверный пароль' });
  }
  const token = signToken({ role: 'admin' }, 12 * 60 * 60 * 1000);
  res.json({ ok: true, token });
});

app.get('/api/me', checkAuth, (req, res) => {
  res.json({
    companyId: req.companyId,
    email: req.company.email,
    plan: req.company.plan,
    usage: {
      submissions: (req.company.usage && req.company.usage.submissions) || 0,
      submissionsLimit: req.company.plan === 'free' ? FREE_MAX_SUBMISSIONS : null,
      testsLimit: req.company.plan === 'free' ? FREE_MAX_TESTS : null,
      questionsLimit: req.company.plan === 'free' ? FREE_MAX_QUESTIONS : null
    }
  });
});

// ==================== ТЕСТЫ ====================

app.get('/api/tests', checkAuth, (req, res) => {
  const data = db.load();
  const list = Object.values(data.tests)
    .filter(t => t.companyId === req.companyId)
    .sort((a, b) => b.createdAt - a.createdAt);
  res.json(list);
});

// Сводка по тегам вопросов компании: сколько вопросов помечено каждым тегом
// (вопросы собираются по всем тестам компании — это и есть общий «банк вопросов»).
// ВАЖНО: этот маршрут должен идти РАНЬШЕ '/api/tests/:id', иначе Express
// примет "tags-summary" за значение :id.
app.get('/api/tests/tags-summary', checkAuth, (req, res) => {
  const data = db.load();
  const counts = {};
  Object.values(data.tests)
    .filter(t => t.companyId === req.companyId)
    .forEach(t => {
      t.questions.forEach(q => {
        (q.tags || []).forEach(tag => { counts[tag] = (counts[tag] || 0) + 1; });
      });
    });
  const tags = Object.entries(counts)
    .map(([tag, count]) => ({ tag, count }))
    .sort((a, b) => b.count - a.count);
  res.json({ tags });
});

app.get('/api/tests/:id', checkAuth, (req, res) => {
  const data = db.load();
  const test = safeGet(data.tests, req.params.id);
  if (!test || test.companyId !== req.companyId) return res.status(404).json({ error: 'Тест не найден' });
  res.json(test);
});

app.post('/api/tests', checkAuth, async (req, res) => {
  const { title, questions } = req.body;
  if (!title || !Array.isArray(questions) || questions.length === 0) {
    return res.status(400).json({ error: 'Нужны название и хотя бы один вопрос' });
  }
  if (req.company.plan === 'free') {
    const data = db.load();
    const count = Object.values(data.tests).filter(t => t.companyId === req.companyId).length;
    if (count >= FREE_MAX_TESTS) {
      return res.status(403).json({ error: `Бесплатный тариф позволяет создать не более ${FREE_MAX_TESTS} тестов. ${DEVELOPER_CONTACTS}` });
    }
    if (questions.length > FREE_MAX_QUESTIONS) {
      return res.status(400).json({ error: `Бесплатный тариф — максимум ${FREE_MAX_QUESTIONS} вопросов в тесте.` });
    }
  }
  const id = participantId();
  const test = {
    id,
    companyId: req.companyId,
    title,
    questions: questions.map((q, i) => ({
      id: 'q' + i,
      text: q.text,
      options: q.options,
      correct: q.correct,
      multi: !!q.multi,
      tags: Array.isArray(q.tags) ? [...new Set(q.tags.map(t => String(t).trim()).filter(Boolean))] : [],
      explain: (q.explain || '').toString().trim(),
      image: sanitizeQuestionImage(q.image)
    })),
    createdAt: Date.now()
  };
  await db.update((data) => { data.tests[id] = test; });
  res.json(test);
});

app.put('/api/tests/:id', checkAuth, async (req, res) => {
  const { title, questions } = req.body;
  if (req.company.plan === 'free' && Array.isArray(questions) && questions.length > FREE_MAX_QUESTIONS) {
    return res.status(400).json({ error: `Бесплатный тариф — максимум ${FREE_MAX_QUESTIONS} вопросов в тесте.` });
  }
  const result = await db.update((data) => {
    const test = safeGet(data.tests, req.params.id);
    if (!test || test.companyId !== req.companyId) return null;
    test.title = title;
    test.questions = questions.map((q, i) => ({
      id: q.id || 'q' + i,
      text: q.text,
      options: q.options,
      correct: q.correct,
      multi: !!q.multi,
      tags: Array.isArray(q.tags) ? [...new Set(q.tags.map(t => String(t).trim()).filter(Boolean))] : [],
      explain: (q.explain || '').toString().trim(),
      image: sanitizeQuestionImage(q.image)
    }));
    return test;
  });
  if (!result) return res.status(404).json({ error: 'Тест не найден' });
  res.json(result);
});

app.delete('/api/tests/:id', checkAuth, async (req, res) => {
  await db.update((data) => {
    const test = safeGet(data.tests, req.params.id);
    if (test && test.companyId === req.companyId) {
      delete data.tests[req.params.id];
      Object.keys(data.sessions).forEach(code => {
        if (data.sessions[code].testId === req.params.id && data.sessions[code].companyId === req.companyId) {
          delete data.sessions[code];
        }
      });
    }
  });
  res.json({ ok: true });
});

// Собирает новый тест «вразброс» из вопросов с выбранными тегами (по всем тестам компании).
app.post('/api/tests/generate', checkAuth, async (req, res) => {
  const { title, tags, count } = req.body;
  if (!title || !Array.isArray(tags) || tags.length === 0) {
    return res.status(400).json({ error: 'Укажите название и хотя бы один тег' });
  }
  const wantCount = Math.max(1, Math.min(200, parseInt(count, 10) || 20));
  const data = db.load();
  if (req.company.plan === 'free') {
    const existingCount = Object.values(data.tests).filter(t => t.companyId === req.companyId).length;
    if (existingCount >= FREE_MAX_TESTS) {
      return res.status(403).json({ error: `Бесплатный тариф позволяет создать не более ${FREE_MAX_TESTS} тестов. ${DEVELOPER_CONTACTS}` });
    }
  }
  const tagSet = new Set(tags);
  const pool = [];
  const seenText = new Set(); // защита от дублей одного и того же вопроса из разных тестов
  Object.values(data.tests)
    .filter(t => t.companyId === req.companyId)
    .forEach(t => {
      t.questions.forEach(q => {
        if ((q.tags || []).some(tag => tagSet.has(tag)) && !seenText.has(q.text)) {
          seenText.add(q.text);
          pool.push(q);
        }
      });
    });
  if (pool.length === 0) {
    return res.status(400).json({ error: 'По выбранным темам не нашлось вопросов' });
  }
  // Перемешиваем и берём нужное количество (или все, если запрошено больше, чем есть)
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  const maxAllowed = req.company.plan === 'free' ? Math.min(wantCount, FREE_MAX_QUESTIONS) : wantCount;
  const selected = pool.slice(0, Math.min(maxAllowed, pool.length));

  const id = participantId();
  const test = {
    id,
    companyId: req.companyId,
    title,
    questions: selected.map((q, i) => ({
      id: 'q' + i,
      text: q.text,
      options: q.options,
      correct: q.correct,
      multi: !!q.multi,
      tags: q.tags || [],
      explain: q.explain || '',
      image: q.image || null
    })),
    createdAt: Date.now()
  };
  await db.update((d) => { d.tests[id] = test; });
  res.json({ test, availableInPool: pool.length, selectedCount: selected.length });
});

// Очистка истории прохождений теста (сессии удаляются, счётчик пробного периода НЕ сбрасывается)
app.delete('/api/tests/:id/sessions', checkAuth, async (req, res) => {
  const result = await db.update((data) => {
    const test = safeGet(data.tests, req.params.id);
    if (!test || test.companyId !== req.companyId) return null;
    Object.keys(data.sessions).forEach(code => {
      const s = data.sessions[code];
      if (s.testId === req.params.id && s.companyId === req.companyId && !s.type) {
        delete data.sessions[code];
      }
    });
    return true;
  });
  if (!result) return res.status(404).json({ error: 'Тест не найден' });
  res.json({ ok: true });
});

// ==================== СТАТИСТИКА ====================

// Ручной предварительный перевод всего теста на казахский ОДНИМ нажатием кнопки
// в редакторе (вместо перевода «на лету» во время реальной сдачи студентами).
// Собирает заголовок теста и все тексты вопросов/вариантов ответов, прогоняет их
// через переводчик (Yandex, если настроен, иначе резервный MyMemory) и складывает
// в общий кэш переводов. После этого студенты при переключении на KZ будут читать
// уже готовый перевод из кэша — без единого живого запроса к сервису перевода
// во время самого тестирования, что снимает любые проблемы с лимитами запросов.
app.post('/api/tests/:id/translate', checkAuth, async (req, res) => {
  const data = db.load();
  const test = safeGet(data.tests, req.params.id);
  if (!test || test.companyId !== req.companyId) return res.status(404).json({ error: 'Тест не найден' });

  const texts = [test.title];
  test.questions.forEach(q => {
    texts.push(q.text);
    (q.options || []).forEach(o => texts.push(o));
  });
  const uniqueTexts = [...new Set(texts.filter(t => (t || '').toString().trim()))];

  try {
    await translateBatch(uniqueTexts, 'kk');
    res.json({ ok: true, translated: uniqueTexts.length, provider: USE_YANDEX ? 'yandex' : 'mymemory' });
  } catch (e) {
    console.error('[translate] Ошибка предварительного перевода теста:', e.message);
    res.status(500).json({ error: 'Не удалось выполнить перевод, попробуйте ещё раз' });
  }
});


app.get('/api/tests/:id/stats', checkAuth, (req, res) => {
  const data = db.load();
  const test = safeGet(data.tests, req.params.id);
  if (!test || test.companyId !== req.companyId) return res.status(404).json({ error: 'Тест не найден' });
  const sessions = Object.values(data.sessions)
    .filter(s => s.testId === req.params.id && s.companyId === req.companyId && !s.type)
    .sort((a, b) => a.startedAt - b.startedAt);
  const sessionStats = sessions.map(s => {
    const participants = Object.values(s.participants).filter(p => p.finished);
    const count = participants.length;
    const avgScore = count > 0 ? Math.round((participants.reduce((sum, p) => sum + (p.score / p.total * 100), 0) / count) * 10) / 10 : null;
    return {
      code: s.code,
      startedAt: s.startedAt,
      ended: s.ended,
      totalParticipants: Object.keys(s.participants).length,
      finishedParticipants: count,
      avgScore
    };
  });
  const questionStats = test.questions.map(q => {
    let correct = 0;
    let total = 0;
    sessions.forEach(s => {
      Object.values(s.participants).forEach(p => {
        if (!p.finished || !p.answers) return;
        const a = p.answers[q.id];
        if (!a) return;
        total++;
        if (a.isCorrect) correct++;
      });
    });
    return {
      id: q.id,
      text: q.text,
      correct,
      total,
      errorRate: total > 0 ? Math.round(((total - correct) / total) * 100) : null
    };
  }).sort((a, b) => (b.errorRate || 0) - (a.errorRate || 0));
  res.json({ test: { id: test.id, title: test.title }, sessionStats, questionStats });
});

// Статистика по вопросам за ОДНУ конкретную сессию (группу), а не по всей истории
// теста. Нужна, чтобы посмотреть ошибки текущей/только что прошедшей группы прямо
// во время работы, не трогая и не стирая общую историю теста перед следующей группой.
app.get('/api/sessions/:code/stats', checkAuth, (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.companyId !== req.companyId || session.type === 'lab') {
    return res.status(404).json({ error: 'Сессия не найдена' });
  }
  const test = safeGet(data.tests, session.testId);
  if (!test) return res.status(404).json({ error: 'Тест не найден' });

  const allParticipants = Object.values(session.participants);
  const finished = allParticipants.filter(p => p.finished);

  const questionStats = test.questions.map(q => {
    let correct = 0;
    let total = 0;
    finished.forEach(p => {
      if (!p.answers) return;
      const a = p.answers[q.id];
      if (!a) return;
      total++;
      if (a.isCorrect) correct++;
    });
    return {
      id: q.id,
      text: q.text,
      correct,
      total,
      errorRate: total > 0 ? Math.round(((total - correct) / total) * 100) : null
    };
  }).sort((a, b) => (b.errorRate || 0) - (a.errorRate || 0));

  res.json({
    testTitle: test.title,
    code: session.code,
    totalParticipants: allParticipants.length,
    finishedParticipants: finished.length,
    questionStats
  });
});

// ==================== QR-КОД (ОТДЕЛЬНЫЙ МАРШРУТ ДЛЯ КАРТИНКИ) ====================
app.get('/api/sessions/:code/qr', async (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session) return res.status(404).json({ error: 'Сессия не найдена' });
  const url = `${getBaseUrl()}/s/${req.params.code}`;
  const qrDataUrl = await QRCode.toDataURL(url, { width: 400, margin: 1 });
  res.setHeader('Content-Type', 'image/png');
  res.send(Buffer.from(qrDataUrl.split(',')[1], 'base64'));
});

// ==================== СЕССИИ ====================

app.post('/api/sessions', checkAuth, async (req, res) => {
  const { testId } = req.body;
  const data = db.load();
  const test = safeGet(data.tests, testId);
  if (!test || test.companyId !== req.companyId) return res.status(404).json({ error: 'Тест не найден' });
  let scheduledAt = null;
  if (req.body.scheduledAt) {
    const ts = parseInt(req.body.scheduledAt, 10);
    if (!isNaN(ts) && ts > Date.now()) scheduledAt = ts;
  }
  let code;
  do { code = nanoid(); } while (safeGet(data.sessions, code));
  const session = {
    code,
    companyId: req.companyId,
    testId,
    testTitle: test.title,
    timeLimit: req.body.timeLimit || null,
    startedAt: Date.now(),
    scheduledAt,
    ended: false,
    participants: {}
  };
  await db.update((d) => { d.sessions[code] = session; });
  const url = `${getBaseUrl()}/s/${code}`;
  const qrDataUrl = await QRCode.toDataURL(url, { width: 400, margin: 1 });
  res.json({ session, url, qrDataUrl });
});

app.post('/api/sessions/:code/start-now', checkAuth, async (req, res) => {
  const result = await db.update((d) => {
    const session = safeGet(d.sessions, req.params.code);
    if (!session || session.companyId !== req.companyId) return null;
    session.scheduledAt = null;
    return session;
  });
  if (!result) return res.status(404).json({ error: 'Сессия не найдена' });
  res.json({ ok: true });
});

app.get('/api/sessions/:code/info', (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type === 'lab') return res.status(404).json({ error: 'Сессия не найдена' });
  const trialMsg = trialBlockedForCompany(data, session.companyId);
  if (trialMsg) return res.status(403).json({ error: 'TRIAL_ENDED', message: trialMsg });
  const test = safeGet(data.tests, session.testId);
  res.json({
    testTitle: session.testTitle,
    timeLimit: session.timeLimit || null,
    ended: !!session.ended,
    scheduledAt: session.scheduledAt || null,
    questionCount: test ? test.questions.length : 0
  });
});

// Публичный эндпоинт для «витрины показа» (/present.html): повторно отдаёт QR-код и
// ссылку по коду сессии — без имён участников, результатов и другой чувствительной информации,
// чтобы можно было безопасно открыть на проекторе/втором экране в классе.
app.get('/api/sessions/:code/present', async (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session) return res.status(404).json({ error: 'Сессия не найдена' });
  const pathPrefix = session.type === 'lab' ? 'l' : session.type === 'drawing' ? 'd' : session.type === 'tolerance' ? 'k' : 's';
  const url = `${getBaseUrl()}/${pathPrefix}/${session.code}`;
  try {
    const qrDataUrl = await QRCode.toDataURL(url, { width: 500, margin: 1 });
    res.json({
      testTitle: session.testTitle,
      code: session.code,
      url,
      qrDataUrl,
      type: session.type || 'test',
      ended: !!session.ended,
      scheduledAt: session.scheduledAt || null
    });
  } catch (e) {
    res.status(500).json({ error: 'Не удалось сформировать QR-код' });
  }
});

app.post('/api/sessions/:code/join', joinLimiter, async (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Введите имя' });
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type === 'lab') return res.status(404).json({ error: 'Сессия не найдена' });
  if (session.ended) return res.status(410).json({ error: 'Тестирование завершено' });
  if (session.scheduledAt && Date.now() < session.scheduledAt) {
    return res.status(403).json({
      error: 'NOT_STARTED',
      message: `Тестирование ещё не началось. Начало запланировано на ${new Date(session.scheduledAt).toLocaleString('ru-RU')}.`,
      scheduledAt: session.scheduledAt
    });
  }
  const trialMsg = trialBlockedForCompany(data, session.companyId);
  if (trialMsg) return res.status(403).json({ error: 'TRIAL_ENDED', message: trialMsg });
  const test = safeGet(data.tests, session.testId);
  if (!test) return res.status(404).json({ error: 'Тест не найден' });

  // Запрет повторного захода под тем же именем в уже пройденную сессию: если участник
  // с таким именем (без учёта регистра и лишних пробелов) уже завершил тест в этой
  // сессии — не даём открыть его заново под тем же именем (защита от повторной сдачи
  // за себя или подглядывания в свой же уже сданный результат).
  const nameKey = name.trim().toLowerCase();
  const alreadyFinished = Object.values(session.participants).some(
    p => p.finished && p.name.trim().toLowerCase() === nameKey
  );
  if (alreadyFinished) {
    return res.status(409).json({
      error: 'ALREADY_SUBMITTED',
      message: 'Участник с таким именем уже проходил это тестирование. Если это ошибка, обратитесь к преподавателю.'
    });
  }

  const pid = participantId();

  // Перемешиваем порядок вопросов и порядок вариантов ответа индивидуально для
  // каждого участника (защита от списывания у соседа на очном тестировании).
  // Карта optionShuffle[qId][новая_позиция] = исходный_индекс — сохраняется у
  // участника, чтобы при проверке ответов перевести их обратно в исходную систему координат.
  const optionShuffle = {};
  const shuffledQuestions = test.questions.map(q => {
    const order = shuffleArr(q.options.map((_, i) => i));
    optionShuffle[q.id] = order;
    return {
      id: q.id,
      text: q.text,
      options: order.map(origIdx => q.options[origIdx]),
      multi: !!q.multi,
      image: q.image || null
    };
  });
  const orderedQuestions = shuffleArr(shuffledQuestions);

  const participant = {
    id: pid,
    name: name.trim().slice(0, 80),
    joinedAt: Date.now(),
    answers: {},
    finished: false,
    score: null,
    total: null,
    optionShuffle,
    tabSwitchCount: 0,
    tabSwitchTotalMs: 0
  };
  await db.update((d) => { d.sessions[req.params.code].participants[pid] = participant; });
  io.to('session:' + req.params.code).emit('participant:joined', participant);
  res.json({
    participantId: pid,
    testTitle: test.title,
    timeLimit: session.timeLimit || null,
    questions: orderedQuestions
  });
});

app.post('/api/sessions/:code/submit', async (req, res) => {
  const { participantId: pid, answers, tabSwitchLog } = req.body;
  const safeAnswers = answers && typeof answers === 'object' ? answers : {};
  const safeTabLog = Array.isArray(tabSwitchLog) ? tabSwitchLog.slice(0, 200) : [];
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session) return res.status(404).json({ error: 'Сессия не найдена' });
  const participant = safeGet(session.participants, pid);
  if (!participant) return res.status(404).json({ error: 'Участник не найден' });
  if (participant.finished) return res.status(400).json({ error: 'Тест уже сдан' });
  const test = safeGet(data.tests, session.testId);
  if (!test) return res.status(404).json({ error: 'Тест не найден' });
  let score = 0;
  const total = test.questions.length;
  const detail = {};
  const optionShuffle = participant.optionShuffle || {};
  for (const q of test.questions) {
    const rawGiven = safeAnswers[q.id];
    const mapping = optionShuffle[q.id]; // [новая_позиция] = исходный_индекс
    let given = rawGiven;
    if (mapping) {
      if (q.multi) {
        given = Array.isArray(rawGiven) ? rawGiven.map(i => mapping[i]).filter(v => v !== undefined) : [];
      } else if (rawGiven !== undefined && rawGiven !== null) {
        given = mapping[rawGiven] !== undefined ? mapping[rawGiven] : rawGiven;
      }
    }
    let isCorrect = false;
    if (q.multi) {
      const correctSet = JSON.stringify([...q.correct].sort());
      const givenSet = JSON.stringify([...(Array.isArray(given) ? given : [])].sort());
      isCorrect = correctSet === givenSet;
    } else {
      isCorrect = given === q.correct;
    }
    if (isCorrect) score++;
    detail[q.id] = { given, correct: q.correct, isCorrect };
  }
  const result = await db.update((d) => {
    const p = safeGet(d.sessions[req.params.code].participants, pid);
    p.answers = detail;
    p.finished = true;
    p.finishedAt = Date.now();
    p.score = score;
    p.total = total;
    const totalAwayMs = safeTabLog.reduce((sum, e) => sum + (Math.max(0, parseInt(e.awayMs, 10) || 0)), 0);
    p.tabSwitchCount = safeTabLog.length;
    p.tabSwitchTotalMs = totalAwayMs;
    p.tabSwitchLongCount = safeTabLog.filter(e => (Math.max(0, parseInt(e.awayMs, 10) || 0)) >= 5000).length;
    return p;
  });
  await incrementSubmissions(session.companyId);
  const review = test.questions.map(q => ({
    text: q.text,
    options: q.options,
    multi: q.multi,
    given: detail[q.id].given,
    correct: detail[q.id].correct,
    isCorrect: detail[q.id].isCorrect,
    explain: q.explain || '',
    image: q.image || null
  }));
  io.to('session:' + req.params.code).emit('participant:finished', result);
  res.json({ score, total, review });
});

// Анонимный топ-3 по сессии для студента: без имён, только позиции и проценты,
// плюс собственное место (если передан participantId). Публичный маршрут —
// доступен со страницы прохождения теста, авторизация преподавателя не нужна.
app.get('/api/sessions/:code/leaderboard', (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type === 'lab') return res.status(404).json({ error: 'Сессия не найдена' });
  const finished = Object.entries(session.participants)
    .filter(([, p]) => p.finished && p.total > 0)
    .map(([pid, p]) => ({ pid, percent: Math.round((p.score / p.total) * 100), finishedAt: p.finishedAt }))
    .sort((a, b) => b.percent - a.percent || a.finishedAt - b.finishedAt);
  const top = finished.slice(0, 3).map((p, i) => ({ rank: i + 1, percent: p.percent }));
  const myPid = req.query.participantId;
  let yourRank = null;
  if (myPid) {
    const idx = finished.findIndex(p => p.pid === myPid);
    if (idx >= 0) yourRank = idx + 1;
  }
  res.json({ top, yourRank, totalParticipants: finished.length });
});

app.post('/api/sessions/:code/end', checkAuth, async (req, res) => {
  await db.update((d) => {
    const s = safeGet(d.sessions, req.params.code);
    if (s && s.companyId === req.companyId) {
      s.ended = true;
    }
  });
  io.to('session:' + req.params.code).emit('session:ended');
  res.json({ ok: true });
});

app.get('/api/sessions/:code/export', checkAuth, (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.companyId !== req.companyId) return res.status(404).send('Сессия не найдена');
  const test = safeGet(data.tests, session.testId);
  const rows = Object.values(session.participants).map(p => {
    const row = {
      'Имя': p.name,
      'Баллы': p.score !== null ? p.score : '—',
      'Всего вопросов': p.total !== null ? p.total : '—',
      'Процент': p.total ? Math.round((p.score / p.total) * 100) + '%' : '—',
      'Статус': p.finished ? 'Завершил' : 'В процессе',
      'Переключений вкладки': p.tabSwitchCount || 0,
      'Из них долгих (5+ сек)': p.tabSwitchLongCount || 0,
      'Время вне теста, сек': p.tabSwitchTotalMs ? Math.round(p.tabSwitchTotalMs / 1000) : 0
    };
    if (test) {
      test.questions.forEach((q, i) => {
        const d = p.answers[q.id];
        row[`В${i + 1}: ${q.text}`] = d ? (d.isCorrect ? 'Верно' : 'Неверно') : '—';
      });
    }
    return row;
  });
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, 'Результаты');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', `attachment; filename="results_${req.params.code}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

// ==================== ИМПОРТ И ШАБЛОНЫ ====================

app.get('/api/import-template', checkAuth, (req, res) => {
  const headers = ['Вопрос', 'Вариант 1', 'Вариант 2', 'Вариант 3', 'Вариант 4', 'Вариант 5', 'Правильные (номера через запятую)', 'Теги (через запятую, необязательно)', 'Пояснение (необязательно, показывается после сдачи теста)'];
  const example1 = ['Какая муфта применяется во избежание поломок деталей механизма из-за перегрузок?', 'Компенсирующая муфта', 'Жёсткая муфта', 'Предохранительная муфта', 'Обгонная муфта', '', '3', 'приводы и передачи', 'Предохранительная муфта разъединяет вал при превышении допустимого крутящего момента, защищая механизм от поломки.'];
  const example2 = ['Выберите чётные числа', '1', '2', '3', '4', '', '2,4', '', ''];
  const ws = XLSX.utils.aoa_to_sheet([headers, example1, example2]);
  ws['!cols'] = [{ wch: 45 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 30 }, { wch: 30 }, { wch: 50 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Вопросы');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', 'attachment; filename="shablon_voprosov.xlsx"');
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

// Экспорт существующего теста обратно в Excel — тот же формат, что и шаблон импорта,
// чтобы можно было забрать вопросы для правки офлайн и загрузить их снова.
// Изображения вопросов в экспорт не попадают (в файле остаётся только текстовое содержимое).
app.get('/api/tests/:id/export-excel', checkAuth, (req, res) => {
  const data = db.load();
  const test = safeGet(data.tests, req.params.id);
  if (!test || test.companyId !== req.companyId) return res.status(404).json({ error: 'Тест не найден' });
  const headers = ['Вопрос', 'Вариант 1', 'Вариант 2', 'Вариант 3', 'Вариант 4', 'Вариант 5', 'Правильные (номера через запятую)', 'Теги (через запятую, необязательно)', 'Пояснение (необязательно, показывается после сдачи теста)'];
  const rows = test.questions.map(q => {
    const correctIdxs = q.multi ? q.correct : [q.correct];
    const opts = [0, 1, 2, 3, 4].map(i => q.options[i] !== undefined ? q.options[i] : '');
    return [
      q.text,
      ...opts,
      correctIdxs.map(i => i + 1).join(','),
      (q.tags || []).join(', '),
      q.explain || ''
    ];
  });
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  ws['!cols'] = [{ wch: 45 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 30 }, { wch: 30 }, { wch: 50 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Вопросы');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  const asciiFallback = test.title.replace(/[^\x20-\x7E]/g, '_').replace(/[\\/:*?"<>|]/g, '_').slice(0, 60) || 'test';
  const utf8Name = encodeURIComponent(test.title.slice(0, 80) + '.xlsx');
  res.setHeader('Content-Disposition', `attachment; filename="${asciiFallback}.xlsx"; filename*=UTF-8''${utf8Name}`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

app.post('/api/import-questions', checkAuth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Файл не загружен' });
  let rows;
  try {
    const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
  } catch (e) {
    return res.status(400).json({ error: 'Не удалось прочитать файл. Убедитесь, что это .xlsx или .xls' });
  }
  if (rows.length < 2) {
    return res.status(400).json({ error: 'В файле нет вопросов. Заполните строки под заголовком.' });
  }
  const questions = [];
  const skipped = [];
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.every(c => String(c).trim() === '')) continue;
    const text = String(row[0] || '').trim();
    const options = [];
    for (let c = 1; c <= 5; c++) {
      const val = String(row[c] || '').trim();
      if (val) options.push(val);
    }
    const correctRaw = String(row[6] || '').trim();
    if (!text || options.length < 2 || !correctRaw) {
      skipped.push({ row: i + 1, reason: 'нет текста вопроса, вариантов (мин. 2) или правильного ответа' });
      continue;
    }
    const correctNums = correctRaw.split(',').map(s => parseInt(s.trim(), 10)).filter(n => !isNaN(n));
    const correctIdxs = correctNums.map(n => n - 1).filter(idx => idx >= 0 && idx < options.length);
    if (correctIdxs.length === 0) {
      skipped.push({ row: i + 1, reason: 'номер правильного ответа не соответствует вариантам' });
      continue;
    }
    const multi = correctIdxs.length > 1;
    const tagsRaw = String(row[7] || '').trim();
    const tags = tagsRaw ? [...new Set(tagsRaw.split(',').map(t => t.trim()).filter(Boolean))] : [];
    const explain = String(row[8] || '').trim();
    questions.push({ text, options, correct: multi ? correctIdxs : correctIdxs[0], multi, tags, explain });
  }
  if (questions.length === 0) {
    return res.status(400).json({ error: 'Не удалось распознать ни одного вопроса. Проверьте формат файла (скачайте шаблон).', skipped });
  }
  res.json({ questions, skipped });
});

// ==================== ЛАБОРАТОРИИ ====================

function shuffleArr(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function buildOptionsPool(lab) {
  return lab.faults.map(f => ({ id: f.id, label: f.label }));
}

function assignCases(lab) {
  const order = shuffleArr(lab.faults.map(f => f.id));
  return order.map(faultId => {
    const fault = lab.faults.find(f => f.id === faultId);
    const variationIndex = Math.floor(Math.random() * fault.variations.length);
    return { faultId, variationIndex };
  });
}

function caseForClient(lab, assignment) {
  const fault = lab.faults.find(f => f.id === assignment.faultId);
  const v = fault.variations[assignment.variationIndex];
  return {
    title: v.title,
    vibration: v.vibration,
    temp: v.temp,
    sound: v.sound,
    options: shuffleArr(buildOptionsPool(lab))
  };
}

app.get('/api/labs', checkAuth, (req, res) => {
  const data = db.load();
  const list = Object.values(data.labs)
    .filter(l => l.shared || l.companyId === req.companyId)
    .map(l => ({
      id: l.id,
      title: l.title,
      intro: l.intro,
      faultCount: l.faults.length,
      shared: !!l.shared
    }));
  res.json(list);
});

app.get('/api/labs/:id', checkAuth, (req, res) => {
  const data = db.load();
  const lab = safeGet(data.labs, req.params.id);
  if (!lab || (!lab.shared && lab.companyId !== req.companyId)) return res.status(404).json({ error: 'Тренажёр не найден' });
  res.json(lab);
});

function validateLabPayload(body) {
  const { title, faults } = body;
  if (!title || !title.trim()) return 'Введите название тренажёра';
  if (!Array.isArray(faults) || faults.length === 0) return 'Добавьте хотя бы одну неисправность';
  for (const f of faults) {
    if (!f.label || !f.label.trim()) return 'У каждой неисправности должно быть название диагноза';
    if (!f.explain || !f.explain.trim()) return 'У каждой неисправности должно быть объяснение';
    if (!Array.isArray(f.variations) || f.variations.length === 0) {
      return `У неисправности «${f.label}» должна быть хотя бы одна вариация показаний`;
    }
    for (const v of f.variations) {
      if (!v.title || !v.vibration || !v.vibration.value || !v.temp || !v.temp.value || !v.sound || !v.sound.type) {
        return `Заполните все поля показаний в вариациях для «${f.label}»`;
      }
    }
  }
  return null;
}

app.post('/api/labs', checkAuth, async (req, res) => {
  const err = validateLabPayload(req.body);
  if (err) return res.status(400).json({ error: err });
  const id = participantId();
  const lab = {
    id,
    companyId: req.companyId,
    shared: false,
    title: req.body.title.trim(),
    intro: (req.body.intro || '').trim(),
    faults: req.body.faults.map((f, fi) => ({
      id: f.id || ('f' + fi + '_' + id),
      label: f.label.trim(),
      explain: f.explain.trim(),
      variations: f.variations.map(v => ({
        title: v.title.trim(),
        vibration: { value: v.vibration.value.trim(), desc: (v.vibration.desc || '').trim() },
        temp: { value: v.temp.value.trim(), desc: (v.temp.desc || '').trim() },
        sound: { type: v.sound.type, desc: (v.sound.desc || '').trim() }
      }))
    })),
    createdAt: Date.now(),
    custom: true
  };
  await db.update((d) => { d.labs[id] = lab; });
  res.json(lab);
});

app.put('/api/labs/:id', checkAuth, async (req, res) => {
  const err = validateLabPayload(req.body);
  if (err) return res.status(400).json({ error: err });
  const result = await db.update((d) => {
    const existing = safeGet(d.labs, req.params.id);
    if (!existing || existing.shared || existing.companyId !== req.companyId) return null;
    existing.title = req.body.title.trim();
    existing.intro = (req.body.intro || '').trim();
    existing.faults = req.body.faults.map((f, fi) => ({
      id: f.id || ('f' + fi + '_' + req.params.id),
      label: f.label.trim(),
      explain: f.explain.trim(),
      variations: f.variations.map(v => ({
        title: v.title.trim(),
        vibration: { value: v.vibration.value.trim(), desc: (v.vibration.desc || '').trim() },
        temp: { value: v.temp.value.trim(), desc: (v.temp.desc || '').trim() },
        sound: { type: v.sound.type, desc: (v.sound.desc || '').trim() }
      }))
    }));
    return existing;
  });
  if (!result) return res.status(404).json({ error: 'Тренажёр не найден' });
  res.json(result);
});

app.delete('/api/labs/:id', checkAuth, async (req, res) => {
  await db.update((d) => {
    const lab = safeGet(d.labs, req.params.id);
    if (lab && !lab.shared && lab.companyId === req.companyId) {
      delete d.labs[req.params.id];
      Object.keys(d.sessions).forEach(code => {
        if (d.sessions[code].labId === req.params.id && d.sessions[code].companyId === req.companyId) {
          delete d.sessions[code];
        }
      });
    }
  });
  res.json({ ok: true });
});

app.post('/api/lab-sessions', checkAuth, async (req, res) => {
  const { labId } = req.body;
  const data = db.load();
  const lab = safeGet(data.labs, labId);
  if (!lab || (!lab.shared && lab.companyId !== req.companyId)) return res.status(404).json({ error: 'Тренажёр не найден' });
  let scheduledAt = null;
  if (req.body.scheduledAt) {
    const ts = parseInt(req.body.scheduledAt, 10);
    if (!isNaN(ts) && ts > Date.now()) scheduledAt = ts;
  }
  let code;
  do { code = nanoid(); } while (safeGet(data.sessions, code));
  const session = {
    code,
    companyId: req.companyId,
    type: 'lab',
    labId,
    testTitle: lab.title,
    startedAt: Date.now(),
    scheduledAt,
    ended: false,
    participants: {}
  };
  await db.update((d) => { d.sessions[code] = session; });
  const url = `${getBaseUrl()}/l/${code}`;
  const qrDataUrl = await QRCode.toDataURL(url, { width: 400, margin: 1 });
  res.json({ session, url, qrDataUrl });
});

app.post('/api/lab-sessions/:code/start-now', checkAuth, async (req, res) => {
  const result = await db.update((d) => {
    const session = safeGet(d.sessions, req.params.code);
    if (!session || session.companyId !== req.companyId) return null;
    session.scheduledAt = null;
    return session;
  });
  if (!result) return res.status(404).json({ error: 'Сессия не найдена' });
  res.json({ ok: true });
});

app.get('/api/lab-sessions/:code', checkAuth, (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.companyId !== req.companyId || session.type !== 'lab') {
    return res.status(404).json({ error: 'Сессия не найдена' });
  }
  res.json(session);
});

// Публичный маршрут — его вызывает страница студента (/l/:code) ДО присоединения, без авторизации компании.
app.get('/api/lab-sessions/:code/info', (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'lab') return res.status(404).json({ error: 'Сессия не найдена' });
  if (session.ended) return res.status(410).json({ error: 'Тренажёр завершён' });
  const trialMsg = trialBlockedForCompany(data, session.companyId);
  if (trialMsg) return res.status(403).json({ error: 'TRIAL_ENDED', message: trialMsg });
  const lab = safeGet(data.labs, session.labId);
  res.json({ testTitle: session.testTitle, intro: lab ? lab.intro : '', caseCount: lab ? lab.faults.length : 0, scheduledAt: session.scheduledAt || null });
});

app.post('/api/lab-sessions/:code/join', joinLimiter, async (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Введите имя' });
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'lab') return res.status(404).json({ error: 'Сессия не найдена' });
  if (session.ended) return res.status(410).json({ error: 'Тренажёр завершён' });
  if (session.scheduledAt && Date.now() < session.scheduledAt) {
    return res.status(403).json({
      error: 'NOT_STARTED',
      message: `Тренажёр ещё не начался. Начало запланировано на ${new Date(session.scheduledAt).toLocaleString('ru-RU')}.`,
      scheduledAt: session.scheduledAt
    });
  }
  const trialMsg = trialBlockedForCompany(data, session.companyId);
  if (trialMsg) return res.status(403).json({ error: 'TRIAL_ENDED', message: trialMsg });
  const lab = safeGet(data.labs, session.labId);
  if (!lab) return res.status(404).json({ error: 'Тренажёр не найден' });
  const pid = participantId();
  const caseAssignment = assignCases(lab);
  const participant = {
    id: pid,
    name: name.trim().slice(0, 80),
    joinedAt: Date.now(),
    caseAssignment,
    finished: false,
    score: null,
    total: null
  };
  await db.update((d) => { d.sessions[req.params.code].participants[pid] = participant; });
  io.to('session:' + req.params.code).emit('participant:joined', participant);
  res.json({
    participantId: pid,
    testTitle: lab.title,
    cases: caseAssignment.map(a => caseForClient(lab, a))
  });
});

app.post('/api/lab-sessions/:code/submit', async (req, res) => {
  const { participantId: pid, answers } = req.body;
  const safeAnswers = Array.isArray(answers) ? answers : [];
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'lab') return res.status(404).json({ error: 'Сессия не найдена' });
  const participant = safeGet(session.participants, pid);
  if (!participant) return res.status(404).json({ error: 'Участник не найден' });
  if (participant.finished) return res.status(400).json({ error: 'Тренажёр уже сдан' });
  const lab = safeGet(data.labs, session.labId);
  if (!lab) return res.status(404).json({ error: 'Тренажёр не найден' });
  let score = 0;
  const total = participant.caseAssignment.length;
  const review = [];
  participant.caseAssignment.forEach((assignment, i) => {
    const fault = lab.faults.find(f => f.id === assignment.faultId);
    const v = fault.variations[assignment.variationIndex];
    const given = safeAnswers[i];
    const isCorrect = given === assignment.faultId;
    if (isCorrect) score++;
    review.push({
      title: v.title,
      vibration: v.vibration,
      temp: v.temp,
      sound: v.sound,
      options: buildOptionsPool(lab),
      given,
      correct: assignment.faultId,
      correctLabel: fault.label,
      isCorrect,
      explain: fault.explain
    });
  });
  const result = await db.update((d) => {
    const p = safeGet(d.sessions[req.params.code].participants, pid);
    p.finished = true;
    p.finishedAt = Date.now();
    p.score = score;
    p.total = total;
    p.review = review;
    return p;
  });
  await incrementSubmissions(session.companyId);
  io.to('session:' + req.params.code).emit('participant:finished', result);
  res.json({ score, total, review });
});

app.post('/api/lab-sessions/:code/end', checkAuth, async (req, res) => {
  await db.update((d) => {
    const s = safeGet(d.sessions, req.params.code);
    if (s && s.companyId === req.companyId) {
      s.ended = true;
    }
  });
  io.to('session:' + req.params.code).emit('session:ended');
  res.json({ ok: true });
});

app.get('/api/lab-sessions/:code/export', checkAuth, (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.companyId !== req.companyId || session.type !== 'lab') return res.status(404).send('Сессия не найдена');
  const lab = safeGet(data.labs, session.labId);
  const rows = Object.values(session.participants).map(p => {
    const row = {
      'Имя': p.name,
      'Баллы': p.score !== null ? p.score : '—',
      'Всего случаев': p.total !== null ? p.total : '—',
      'Процент': p.total ? Math.round((p.score / p.total) * 100) + '%' : '—',
      'Статус': p.finished ? 'Завершил' : 'В процессе'
    };
    if (p.review) {
      p.review.forEach((c, i) => {
        row[`Случай ${i + 1}: ${c.title}`] = c.isCorrect ? 'Верно' : `Неверно (${c.correctLabel})`;
      });
    }
    return row;
  });
  const faultStats = {};
  if (lab) lab.faults.forEach(f => { faultStats[f.label] = { wrong: 0, total: 0 }; });
  Object.values(session.participants).forEach(p => {
    if (!p.review) return;
    p.review.forEach(c => {
      if (!faultStats[c.correctLabel]) faultStats[c.correctLabel] = { wrong: 0, total: 0 };
      faultStats[c.correctLabel].total++;
      if (!c.isCorrect) faultStats[c.correctLabel].wrong++;
    });
  });
  const summaryRows = Object.entries(faultStats).map(([label, s]) => ({
    'Тип неисправности': label,
    'Ошибок': s.wrong,
    'Всего показов': s.total,
    'Доля ошибок': s.total ? Math.round((s.wrong / s.total) * 100) + '%' : '—'
  }));
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, 'Результаты');
  const wsSummary = XLSX.utils.json_to_sheet(summaryRows);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'Проблемные типы');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', `attachment; filename="lab_results_${req.params.code}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

app.get('/l/:code', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'lab-student.html'));
});

app.get('/s/:code', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'student.html'));
});

app.get('/d/:code', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'drawing-student.html'));
});

app.get('/k/:code', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'tolerance-student.html'));
});

// ==================== ЗАДАНИЯ ПО ЧЕРТЕЖАМ (открытые вопросы, ручная проверка) ====================
// Структура и роуты намеренно зеркалят /api/labs и /api/lab-sessions выше, но вместо
// автопроверки по вариантам ответа — свободный текст, который заполняет ученик,
// а преподаватель проверяет и выставляет зачёт/незачёт по каждому пункту вручную.

app.get('/api/drawing-tasks', checkAuth, (req, res) => {
  const data = db.load();
  const list = Object.values(data.drawingTasks)
    .filter(t => t.shared || t.companyId === req.companyId)
    .map(t => ({
      id: t.id,
      title: t.title,
      intro: t.intro,
      questionCount: t.questions.length,
      shared: !!t.shared
    }));
  res.json(list);
});

app.get('/api/drawing-tasks/:id', checkAuth, (req, res) => {
  const data = db.load();
  const task = safeGet(data.drawingTasks, req.params.id);
  if (!task || (!task.shared && task.companyId !== req.companyId)) return res.status(404).json({ error: 'Задание не найдено' });
  res.json(task);
});

function normalizeForMatch(s) {
  return (s || '').toString().toLowerCase().replace(/ё/g, 'е')
    .replace(/[.,;:()«»"'`\-_/\\№#]/g, ' ').replace(/\s+/g, ' ').trim();
}

function textSimilarity(a, b) {
  const na = normalizeForMatch(a), nb = normalizeForMatch(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1;
  if (na.includes(nb) || nb.includes(na)) return 0.9;
  const wa = new Set(na.split(' ').filter(Boolean));
  const wb = new Set(nb.split(' ').filter(Boolean));
  if (wa.size === 0 || wb.size === 0) return 0;
  let inter = 0;
  wa.forEach(w => { if (wb.has(w)) inter++; });
  const union = new Set([...wa, ...wb]).size;
  return union ? inter / union : 0;
}

// Сопоставляет то, что ученик вписал в поле «Деталь / задание №» при входе, с одним из
// готовых ключей ответов (сначала по номеру детали, затем по похожести названия).
// Возвращает { key, confidence } или null, если ничего похожего не нашлось —
// в этом случае преподаватель выбирает деталь вручную на экране проверки.
function matchAnswerKey(data, companyId, partInfo) {
  const keys = Object.values(data.answerKeys).filter(k => k.shared || k.companyId === companyId);
  if (keys.length === 0 || !partInfo || !partInfo.trim()) return null;

  const numMatch = partInfo.match(/(\d{1,3})/);
  if (numMatch) {
    const num = parseInt(numMatch[1], 10);
    const byNumber = keys.find(k => k.number === num);
    if (byNumber) return { key: byNumber, confidence: 1 };
  }

  let best = null, bestScore = 0;
  keys.forEach(k => {
    const score = Math.max(textSimilarity(partInfo, k.name), textSimilarity(partInfo, k.title));
    if (score > bestScore) { bestScore = score; best = k; }
  });
  if (best && bestScore >= 0.5) return { key: best, confidence: bestScore };
  return null;
}

// Сопоставляет вопросы задания (task.questions) с вопросами ключа по тексту, а не по
// порядку/id — так матчинг переживает правки текста пункта бланка преподавателем.
function resolveKeyAnswers(taskQuestions, key) {
  if (!key) return null;
  return taskQuestions.map(q => {
    const found = key.questions.find(kq => normalizeForMatch(kq.text) === normalizeForMatch(q.text))
      || key.questions.find(kq => textSimilarity(kq.text, q.text) >= 0.7);
    return found ? found.answer : null;
  });
}

function validateDrawingTaskPayload(body) {
  const { title, questions } = body;
  if (!title || !title.trim()) return 'Введите название задания';
  if (!Array.isArray(questions) || questions.length === 0) return 'Добавьте хотя бы один вопрос';
  for (const q of questions) {
    if (!q.text || !q.text.trim()) return 'У каждого пункта бланка должен быть текст вопроса';
  }
  return null;
}

app.get('/api/drawing-import-template', checkAuth, (req, res) => {
  const headers = ['Пункт бланка (вопрос)', 'Правильный ответ (ключ, необязательно)'];
  const rows = SEED_DRAWING_TASKS[0].questions.map(q => [q.text, '']);
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
  ws['!cols'] = [{ wch: 55 }, { wch: 45 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Бланк');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', 'attachment; filename="shablon_chertezh.xlsx"');
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

// Импорт из Excel: две колонки — текст пункта и (опционально) ключ ответа под конкретный
// чертёж. Ничего не сохраняет сам — просто возвращает распознанные пункты, дальше
// преподаватель проверяет их в редакторе задания и жмёт «Сохранить» как обычно.
app.post('/api/drawing-tasks/import', checkAuth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Файл не загружен' });
  let rows;
  try {
    const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
  } catch (e) {
    return res.status(400).json({ error: 'Не удалось прочитать файл. Убедитесь, что это .xlsx или .xls' });
  }
  if (rows.length < 2) {
    return res.status(400).json({ error: 'В файле нет строк с вопросами под заголовком.' });
  }
  const questions = [];
  const skipped = [];
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row || row.every(c => String(c).trim() === '')) continue;
    const text = String(row[0] || '').trim();
    const correctAnswer = String(row[1] || '').trim();
    if (!text) { skipped.push({ row: i + 1, reason: 'пустой текст вопроса' }); continue; }
    questions.push({ text, correctAnswer });
  }
  if (questions.length === 0) {
    return res.status(400).json({ error: 'Не удалось распознать ни одного пункта. Проверьте формат файла (скачайте шаблон).', skipped });
  }
  res.json({ questions, skipped });
});

app.post('/api/drawing-tasks', checkAuth, async (req, res) => {
  const err = validateDrawingTaskPayload(req.body);
  if (err) return res.status(400).json({ error: err });
  const id = participantId();
  const task = {
    id,
    companyId: req.companyId,
    shared: false,
    title: req.body.title.trim(),
    intro: (req.body.intro || '').trim(),
    questions: req.body.questions.map((q, qi) => ({
      id: q.id || ('q' + qi + '_' + id),
      text: q.text.trim(),
      correctAnswer: (q.correctAnswer || '').trim()
    })),
    createdAt: Date.now(),
    custom: true
  };
  await db.update((d) => { d.drawingTasks[id] = task; });
  res.json(task);
});

app.put('/api/drawing-tasks/:id', checkAuth, async (req, res) => {
  const err = validateDrawingTaskPayload(req.body);
  if (err) return res.status(400).json({ error: err });
  const result = await db.update((d) => {
    const existing = safeGet(d.drawingTasks, req.params.id);
    if (!existing || existing.shared || existing.companyId !== req.companyId) return null;
    existing.title = req.body.title.trim();
    existing.intro = (req.body.intro || '').trim();
    existing.questions = req.body.questions.map((q, qi) => ({
      id: q.id || ('q' + qi + '_' + req.params.id),
      text: q.text.trim(),
      correctAnswer: (q.correctAnswer || '').trim()
    }));
    return existing;
  });
  if (!result) return res.status(404).json({ error: 'Задание не найдено' });
  res.json(result);
});

app.delete('/api/drawing-tasks/:id', checkAuth, async (req, res) => {
  await db.update((d) => {
    const task = safeGet(d.drawingTasks, req.params.id);
    if (task && !task.shared && task.companyId === req.companyId) {
      delete d.drawingTasks[req.params.id];
      Object.keys(d.sessions).forEach(code => {
        if (d.sessions[code].drawingTaskId === req.params.id && d.sessions[code].companyId === req.companyId) {
          delete d.sessions[code];
        }
      });
    }
  });
  res.json({ ok: true });
});

app.post('/api/drawing-sessions', checkAuth, async (req, res) => {
  const { drawingTaskId } = req.body;
  const data = db.load();
  const task = safeGet(data.drawingTasks, drawingTaskId);
  if (!task || (!task.shared && task.companyId !== req.companyId)) return res.status(404).json({ error: 'Задание не найдено' });
  let scheduledAt = null;
  if (req.body.scheduledAt) {
    const ts = parseInt(req.body.scheduledAt, 10);
    if (!isNaN(ts) && ts > Date.now()) scheduledAt = ts;
  }
  let code;
  do { code = nanoid(); } while (safeGet(data.sessions, code));
  const session = {
    code,
    companyId: req.companyId,
    type: 'drawing',
    drawingTaskId,
    testTitle: task.title,
    startedAt: Date.now(),
    scheduledAt,
    ended: false,
    participants: {}
  };
  await db.update((d) => { d.sessions[code] = session; });
  const url = `${getBaseUrl()}/d/${code}`;
  const qrDataUrl = await QRCode.toDataURL(url, { width: 400, margin: 1 });
  res.json({ session, url, qrDataUrl });
});

app.post('/api/drawing-sessions/:code/start-now', checkAuth, async (req, res) => {
  const result = await db.update((d) => {
    const session = safeGet(d.sessions, req.params.code);
    if (!session || session.companyId !== req.companyId) return null;
    session.scheduledAt = null;
    return session;
  });
  if (!result) return res.status(404).json({ error: 'Сессия не найдена' });
  res.json({ ok: true });
});

// Для преподавателя — полная сессия с ответами участников (для проверки).
app.get('/api/drawing-sessions/:code', checkAuth, (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.companyId !== req.companyId || session.type !== 'drawing') {
    return res.status(404).json({ error: 'Сессия не найдена' });
  }
  const task = safeGet(data.drawingTasks, session.drawingTaskId);

  const answerKeys = Object.values(data.answerKeys)
    .filter(k => k.shared || k.companyId === req.companyId)
    .sort((a, b) => (a.number || 0) - (b.number || 0))
    .map(k => ({ id: k.id, title: k.title, number: k.number, name: k.name, questions: k.questions }));

  const matches = {};
  if (task) {
    Object.values(session.participants).forEach(p => {
      const m = matchAnswerKey(data, req.companyId, p.partInfo);
      matches[p.id] = m ? { keyId: m.key.id, keyTitle: m.key.title, confidence: m.confidence } : null;
    });
  }

  res.json({ session, task: task || null, answerKeys, matches });
});

// Публичный маршрут — вызывает страница ученика (/d/:code) до присоединения, без авторизации компании.
app.get('/api/drawing-sessions/:code/info', (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'drawing') return res.status(404).json({ error: 'Сессия не найдена' });
  if (session.ended) return res.status(410).json({ error: 'Задание завершено' });
  const trialMsg = trialBlockedForCompany(data, session.companyId);
  if (trialMsg) return res.status(403).json({ error: 'TRIAL_ENDED', message: trialMsg });
  const task = safeGet(data.drawingTasks, session.drawingTaskId);
  res.json({
    testTitle: session.testTitle,
    intro: task ? task.intro : '',
    questions: task ? task.questions.map(q => ({ id: q.id, text: q.text })) : [],
    scheduledAt: session.scheduledAt || null
  });
});

app.post('/api/drawing-sessions/:code/join', joinLimiter, async (req, res) => {
  const { name, partInfo } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Введите имя' });
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'drawing') return res.status(404).json({ error: 'Сессия не найдена' });
  if (session.ended) return res.status(410).json({ error: 'Задание завершено' });
  if (session.scheduledAt && Date.now() < session.scheduledAt) {
    return res.status(403).json({
      error: 'NOT_STARTED',
      message: `Задание ещё не началось. Начало запланировано на ${new Date(session.scheduledAt).toLocaleString('ru-RU')}.`,
      scheduledAt: session.scheduledAt
    });
  }
  const trialMsg = trialBlockedForCompany(data, session.companyId);
  if (trialMsg) return res.status(403).json({ error: 'TRIAL_ENDED', message: trialMsg });
  const task = safeGet(data.drawingTasks, session.drawingTaskId);
  if (!task) return res.status(404).json({ error: 'Задание не найдено' });
  const pid = participantId();
  const participant = {
    id: pid,
    name: name.trim().slice(0, 80),
    partInfo: (partInfo || '').trim().slice(0, 200),
    joinedAt: Date.now(),
    finished: false,
    answers: null,
    grades: null,
    gradeComment: '',
    graded: false
  };
  await db.update((d) => { d.sessions[req.params.code].participants[pid] = participant; });
  io.to('session:' + req.params.code).emit('participant:joined', participant);
  res.json({
    participantId: pid,
    testTitle: task.title,
    intro: task.intro,
    questions: task.questions.map(q => ({ id: q.id, text: q.text }))
  });
});

app.post('/api/drawing-sessions/:code/submit', async (req, res) => {
  const { participantId: pid, answers } = req.body;
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'drawing') return res.status(404).json({ error: 'Сессия не найдена' });
  const participant = safeGet(session.participants, pid);
  if (!participant) return res.status(404).json({ error: 'Участник не найден' });
  if (participant.finished) return res.status(400).json({ error: 'Бланк уже сдан' });
  const task = safeGet(data.drawingTasks, session.drawingTaskId);
  if (!task) return res.status(404).json({ error: 'Задание не найдено' });
  const safeAnswers = task.questions.map((q, i) => {
    const val = Array.isArray(answers) ? answers[i] : undefined;
    return typeof val === 'string' ? val.trim().slice(0, 2000) : '';
  });
  const result = await db.update((d) => {
    const p = safeGet(d.sessions[req.params.code].participants, pid);
    p.finished = true;
    p.finishedAt = Date.now();
    p.answers = safeAnswers;
    return p;
  });
  await incrementSubmissions(session.companyId);
  io.to('session:' + req.params.code).emit('participant:finished', result);
  res.json({ ok: true });
});

// Публичный маршрут — ученик проверяет свой результат по той же ссылке после проверки
// преподавателем. Правильные ответы отдаём только когда бланк уже проверен (graded),
// чтобы не спалить ключ одноклассникам, которые ещё заполняют тот же бланк.
app.get('/api/drawing-sessions/:code/result', (req, res) => {
  const { participantId: pid } = req.query;
  if (!pid) return res.status(400).json({ error: 'Не указан участник' });
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'drawing') return res.status(404).json({ error: 'Сессия не найдена' });
  const p = safeGet(session.participants, pid);
  if (!p) return res.status(404).json({ error: 'Участник не найден' });
  if (!p.finished) return res.json({ finished: false });
  if (!p.graded) return res.json({ finished: true, graded: false });

  const task = safeGet(data.drawingTasks, session.drawingTaskId);
  const match = task ? matchAnswerKey(data, session.companyId, p.partInfo) : null;
  const resolvedAnswers = task ? resolveKeyAnswers(task.questions, match ? match.key : null) : null;

  const items = (task ? task.questions : []).map((q, i) => ({
    text: q.text,
    given: (p.answers && p.answers[i]) || '',
    correct: p.grades ? p.grades[i] : null,
    correctAnswer: (resolvedAnswers && resolvedAnswers[i]) || q.correctAnswer || null
  }));
  const score = (p.grades || []).filter(g => g === true).length;
  res.json({
    finished: true,
    graded: true,
    score,
    total: items.length,
    gradeComment: p.gradeComment || '',
    items
  });
});

// Ручная проверка бланка преподавателем: массив true/false/null по каждому вопросу + общий комментарий.
app.post('/api/drawing-sessions/:code/grade', checkAuth, async (req, res) => {
  const { participantId: pid, grades, gradeComment } = req.body;
  const result = await db.update((d) => {
    const session = safeGet(d.sessions, req.params.code);
    if (!session || session.companyId !== req.companyId || session.type !== 'drawing') return null;
    const p = safeGet(session.participants, pid);
    if (!p) return null;
    p.grades = Array.isArray(grades) ? grades.map(g => (g === true ? true : g === false ? false : null)) : null;
    p.gradeComment = (gradeComment || '').trim().slice(0, 1000);
    p.graded = true;
    return p;
  });
  if (!result) return res.status(404).json({ error: 'Участник или сессия не найдены' });
  res.json({ ok: true });
});

app.post('/api/drawing-sessions/:code/end', checkAuth, async (req, res) => {
  await db.update((d) => {
    const s = safeGet(d.sessions, req.params.code);
    if (s && s.companyId === req.companyId) {
      s.ended = true;
    }
  });
  io.to('session:' + req.params.code).emit('session:ended');
  res.json({ ok: true });
});

app.get('/api/drawing-sessions/:code/export', checkAuth, (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.companyId !== req.companyId || session.type !== 'drawing') return res.status(404).send('Сессия не найдена');
  const task = safeGet(data.drawingTasks, session.drawingTaskId);
  const questions = task ? task.questions : [];
  const rows = Object.values(session.participants).map(p => {
    const row = {
      'Имя': p.name,
      'Деталь / задание №': p.partInfo || '',
      'Статус': p.finished ? 'Сдал' : 'В процессе',
      'Проверено': p.graded ? 'Да' : 'Нет',
      'Баллы': p.grades ? p.grades.filter(g => g === true).length : '—',
      'Всего пунктов': questions.length
    };
    questions.forEach((q, i) => {
      row[`Ответ: ${q.text}`] = p.answers ? (p.answers[i] || '') : '';
      if (q.correctAnswer) row[`Ключ: ${q.text}`] = q.correctAnswer;
      if (p.grades) row[`Оценка: ${q.text}`] = p.grades[i] === true ? 'Зачёт' : p.grades[i] === false ? 'Незачёт' : '—';
    });
    row['Комментарий проверяющего'] = p.gradeComment || '';
    return row;
  });
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, 'Результаты');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', `attachment; filename="drawing_results_${req.params.code}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

// ==================== КВАЛИТЕТЫ (расчёт допусков, автопроверка) ====================
// В отличие от чертежей и тренажёров, здесь правильный ответ вычисляется по формуле
// (см. tolerance-content.js), поэтому проверка полностью автоматическая. Раздача
// вариантов — по очереди подключения (round-robin по индексу присоединения), а не
// случайно: session.nextVariantIndex увеличивается на 1 при каждом join.

const TOL_UM_EPS = 0.01;   // допуск сравнения в мкм (защита от погрешности округления)
const TOL_MM_EPS = 0.0006; // допуск сравнения в мм (~0.5 мкм)

function parseNum(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = parseFloat(String(v).replace(',', '.').replace(/\s/g, ''));
  return isNaN(n) ? null : n;
}

function fieldLabels(kind) {
  return kind === 'hole'
    ? { devMax: 'ES', devMin: 'EI', limMax: 'Dmax', limMin: 'Dmin', typeName: 'Отверстие' }
    : { devMax: 'es', devMin: 'ei', limMax: 'dmax', limMin: 'dmin', typeName: 'Вал' };
}

app.get('/api/tolerance-tasks', checkAuth, (req, res) => {
  const data = db.load();
  const list = Object.values(data.toleranceTasks)
    .filter(t => t.shared || t.companyId === req.companyId)
    .map(t => ({ id: t.id, title: t.title, intro: t.intro, variantCount: t.variants.length, shared: !!t.shared }));
  res.json(list);
});

app.post('/api/tolerance-sessions', checkAuth, async (req, res) => {
  const { toleranceTaskId } = req.body;
  const data = db.load();
  const task = safeGet(data.toleranceTasks, toleranceTaskId);
  if (!task || (!task.shared && task.companyId !== req.companyId)) return res.status(404).json({ error: 'Задание не найдено' });
  let scheduledAt = null;
  if (req.body.scheduledAt) {
    const ts = parseInt(req.body.scheduledAt, 10);
    if (!isNaN(ts) && ts > Date.now()) scheduledAt = ts;
  }
  let code;
  do { code = nanoid(); } while (safeGet(data.sessions, code));
  const session = {
    code,
    companyId: req.companyId,
    type: 'tolerance',
    toleranceTaskId,
    testTitle: task.title,
    startedAt: Date.now(),
    scheduledAt,
    ended: false,
    nextVariantIndex: 0,
    participants: {}
  };
  await db.update((d) => { d.sessions[code] = session; });
  const url = `${getBaseUrl()}/k/${code}`;
  const qrDataUrl = await QRCode.toDataURL(url, { width: 400, margin: 1 });
  res.json({ session, url, qrDataUrl });
});

app.post('/api/tolerance-sessions/:code/start-now', checkAuth, async (req, res) => {
  const result = await db.update((d) => {
    const session = safeGet(d.sessions, req.params.code);
    if (!session || session.companyId !== req.companyId) return null;
    session.scheduledAt = null;
    return session;
  });
  if (!result) return res.status(404).json({ error: 'Сессия не найдена' });
  res.json({ ok: true });
});

app.get('/api/tolerance-sessions/:code', checkAuth, (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.companyId !== req.companyId || session.type !== 'tolerance') {
    return res.status(404).json({ error: 'Сессия не найдена' });
  }
  const task = safeGet(data.toleranceTasks, session.toleranceTaskId);
  res.json({ session, task: task || null });
});

app.get('/api/tolerance-sessions/:code/info', (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'tolerance') return res.status(404).json({ error: 'Сессия не найдена' });
  if (session.ended) return res.status(410).json({ error: 'Задание завершено' });
  const trialMsg = trialBlockedForCompany(data, session.companyId);
  if (trialMsg) return res.status(403).json({ error: 'TRIAL_ENDED', message: trialMsg });
  const task = safeGet(data.toleranceTasks, session.toleranceTaskId);
  res.json({
    testTitle: session.testTitle,
    intro: task ? task.intro : '',
    scheduledAt: session.scheduledAt || null
  });
});

app.post('/api/tolerance-sessions/:code/join', joinLimiter, async (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Введите имя' });
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'tolerance') return res.status(404).json({ error: 'Сессия не найдена' });
  if (session.ended) return res.status(410).json({ error: 'Задание завершено' });
  if (session.scheduledAt && Date.now() < session.scheduledAt) {
    return res.status(403).json({
      error: 'NOT_STARTED',
      message: `Задание ещё не началось. Начало запланировано на ${new Date(session.scheduledAt).toLocaleString('ru-RU')}.`,
      scheduledAt: session.scheduledAt
    });
  }
  const trialMsg = trialBlockedForCompany(data, session.companyId);
  if (trialMsg) return res.status(403).json({ error: 'TRIAL_ENDED', message: trialMsg });
  const task = safeGet(data.toleranceTasks, session.toleranceTaskId);
  if (!task || task.variants.length === 0) return res.status(404).json({ error: 'Задание не найдено' });

  const pid = participantId();
  let variant;
  await db.update((d) => {
    const s = d.sessions[req.params.code];
    const idx = (s.nextVariantIndex || 0) % task.variants.length;
    variant = task.variants[idx];
    s.nextVariantIndex = idx + 1;
    s.participants[pid] = {
      id: pid,
      name: name.trim().slice(0, 80),
      variantId: variant.id,
      joinedAt: Date.now(),
      finished: false,
      answers: null,
      correct: null,
      score: null,
      graded: false
    };
  });
  io.to('session:' + req.params.code).emit('participant:joined', session.participants[pid] || { id: pid, name: name.trim() });
  const labels = fieldLabels(variant.kind);
  const fieldsTable = variant.kind === 'hole' ? HOLE_FIELDS : SHAFT_FIELDS;
  res.json({
    participantId: pid,
    testTitle: task.title,
    intro: task.intro,
    methodology: task.methodology || [],
    variant: { kind: variant.kind, typeName: labels.typeName, nominal: variant.nominal, field: variant.field },
    labels,
    table: {
      ranges: TOLERANCE_RANGES,
      fieldNames: Object.keys(fieldsTable),
      rows: Object.keys(fieldsTable).reduce((acc, f) => { acc[f] = fieldsTable[f]; return acc; }, {}),
      highlightRow: toleranceRangeIndex(variant.nominal),
      highlightCol: variant.field
    }
  });
});

app.post('/api/tolerance-sessions/:code/submit', async (req, res) => {
  const { participantId: pid, values } = req.body;
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'tolerance') return res.status(404).json({ error: 'Сессия не найдена' });
  const participant = safeGet(session.participants, pid);
  if (!participant) return res.status(404).json({ error: 'Участник не найден' });
  if (participant.finished) return res.status(400).json({ error: 'Ответ уже сдан' });
  const task = safeGet(data.toleranceTasks, session.toleranceTaskId);
  const variant = task ? task.variants.find(v => v.id === participant.variantId) : null;
  if (!variant) return res.status(404).json({ error: 'Вариант не найден' });
  const correctAnswer = computeToleranceAnswer(variant);
  if (!correctAnswer) return res.status(500).json({ error: 'Не удалось вычислить эталонный ответ для этого варианта' });

  const given = {
    devMaxUm: parseNum(values && values.devMaxUm),
    devMinUm: parseNum(values && values.devMinUm),
    devMaxMm: parseNum(values && values.devMaxMm),
    devMinMm: parseNum(values && values.devMinMm),
    limMaxMm: parseNum(values && values.limMaxMm),
    limMinMm: parseNum(values && values.limMinMm)
  };
  const correct = {
    devMaxUm: given.devMaxUm !== null && Math.abs(given.devMaxUm - correctAnswer.devMaxUm) <= TOL_UM_EPS,
    devMinUm: given.devMinUm !== null && Math.abs(given.devMinUm - correctAnswer.devMinUm) <= TOL_UM_EPS,
    devMaxMm: given.devMaxMm !== null && Math.abs(given.devMaxMm - correctAnswer.devMaxMm) <= TOL_MM_EPS,
    devMinMm: given.devMinMm !== null && Math.abs(given.devMinMm - correctAnswer.devMinMm) <= TOL_MM_EPS,
    limMaxMm: given.limMaxMm !== null && Math.abs(given.limMaxMm - correctAnswer.limMaxMm) <= TOL_MM_EPS,
    limMinMm: given.limMinMm !== null && Math.abs(given.limMinMm - correctAnswer.limMinMm) <= TOL_MM_EPS
  };
  const score = Object.values(correct).filter(Boolean).length;

  await db.update((d) => {
    const p = safeGet(d.sessions[req.params.code].participants, pid);
    p.finished = true;
    p.finishedAt = Date.now();
    p.answers = given;
    p.correct = correct;
    p.score = score;
    p.graded = true; // автопроверка — сразу готово
  });
  await incrementSubmissions(session.companyId);
  io.to('session:' + req.params.code).emit('participant:finished', { id: pid, name: participant.name, finished: true, score, total: 6 });
  res.json({ ok: true, score, total: 6 });
});

app.get('/api/tolerance-sessions/:code/result', (req, res) => {
  const { participantId: pid } = req.query;
  if (!pid) return res.status(400).json({ error: 'Не указан участник' });
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.type !== 'tolerance') return res.status(404).json({ error: 'Сессия не найдена' });
  const p = safeGet(session.participants, pid);
  if (!p) return res.status(404).json({ error: 'Участник не найден' });
  if (!p.finished) return res.json({ finished: false });

  const task = safeGet(data.toleranceTasks, session.toleranceTaskId);
  const variant = task ? task.variants.find(v => v.id === p.variantId) : null;
  const correctAnswer = variant ? computeToleranceAnswer(variant) : null;
  const labels = variant ? fieldLabels(variant.kind) : null;

  res.json({
    finished: true,
    graded: true,
    score: p.score,
    total: 6,
    variant: variant ? { kind: variant.kind, typeName: labels.typeName, nominal: variant.nominal, field: variant.field } : null,
    labels,
    given: p.answers,
    correct: p.correct,
    correctAnswer
  });
});

app.post('/api/tolerance-sessions/:code/end', checkAuth, async (req, res) => {
  await db.update((d) => {
    const s = safeGet(d.sessions, req.params.code);
    if (s && s.companyId === req.companyId) s.ended = true;
  });
  io.to('session:' + req.params.code).emit('session:ended');
  res.json({ ok: true });
});

app.get('/api/tolerance-sessions/:code/export', checkAuth, (req, res) => {
  const data = db.load();
  const session = safeGet(data.sessions, req.params.code);
  if (!session || session.companyId !== req.companyId || session.type !== 'tolerance') return res.status(404).send('Сессия не найдена');
  const task = safeGet(data.toleranceTasks, session.toleranceTaskId);
  const rows = Object.values(session.participants).map(p => {
    const variant = task ? task.variants.find(v => v.id === p.variantId) : null;
    const labels = variant ? fieldLabels(variant.kind) : {};
    const ca = variant ? computeToleranceAnswer(variant) : null;
    return {
      'Имя': p.name,
      'Вариант': variant ? `${labels.typeName} Ø${variant.nominal} ${variant.field}` : '—',
      'Статус': p.finished ? 'Сдал' : 'В процессе',
      'Балл': p.score !== null ? `${p.score}/6` : '—',
      [`${labels.devMax || 'ES'} дано (мкм)`]: p.answers ? p.answers.devMaxUm : '',
      [`${labels.devMax || 'ES'} верно (мкм)`]: ca ? ca.devMaxUm : '',
      [`${labels.devMin || 'EI'} дано (мкм)`]: p.answers ? p.answers.devMinUm : '',
      [`${labels.devMin || 'EI'} верно (мкм)`]: ca ? ca.devMinUm : '',
      [`${labels.limMax || 'Dmax'} дано (мм)`]: p.answers ? p.answers.limMaxMm : '',
      [`${labels.limMax || 'Dmax'} верно (мм)`]: ca ? ca.limMaxMm : '',
      [`${labels.limMin || 'Dmin'} дано (мм)`]: p.answers ? p.answers.limMinMm : '',
      [`${labels.limMin || 'Dmin'} верно (мм)`]: ca ? ca.limMinMm : ''
    };
  });
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, 'Результаты');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', `attachment; filename="tolerance_results_${req.params.code}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

io.on('connection', (socket) => {
  socket.on('teacher:watch', (code) => {
    if (typeof code === 'string') socket.join('session:' + code);
  });
  socket.on('teacher:unwatch', (code) => {
    if (typeof code === 'string') socket.leave('session:' + code);
  });

  // Студент сообщает, что вернулся после переключения вкладки/сворачивания приложения
  // во время прохождения теста. Ретранслируем преподавателю, наблюдающему за сессией.
  socket.on('student:tabswitch', (payload) => {
    if (!payload || typeof payload.code !== 'string' || typeof payload.participantId !== 'string') return;
    const awayMs = Math.max(0, parseInt(payload.awayMs, 10) || 0);
    io.to('session:' + payload.code).emit('participant:tabswitch', {
      participantId: payload.participantId,
      awayMs,
      isLong: !!payload.isLong
    });
  });
});

// ==================== АДМИН-ПАНЕЛЬ ====================

app.get('/api/admin/overview', checkAdmin, (req, res) => {
  const data = db.load();
  res.json({
    companies: Object.keys(data.companies).length,
    tests: Object.keys(data.tests).length,
    sessions: Object.keys(data.sessions).length,
    labs: Object.keys(data.labs).length,
    drawingTasks: Object.keys(data.drawingTasks).length
  });
});

app.get('/api/admin/companies', checkAdmin, (req, res) => {
  const data = db.load();
  const list = Object.values(data.companies).map(c => ({
    id: c.id,
    email: c.email,
    name: c.name,
    plan: c.plan,
    blocked: !!c.blocked,
    registeredAt: c.registeredAt,
    testsCount: Object.values(data.tests).filter(t => t.companyId === c.id).length,
    submissions: (c.usage && c.usage.submissions) || 0,
    submissionsLimit: FREE_MAX_SUBMISSIONS
  })).sort((a, b) => b.registeredAt - a.registeredAt);
  res.json(list);
});

app.post('/api/admin/companies/:id/plan', checkAdmin, async (req, res) => {
  const { plan } = req.body;
  if (!['free', 'unlimited'].includes(plan)) return res.status(400).json({ error: 'Некорректный тариф' });
  const result = await db.update((d) => {
    const c = safeGet(d.companies, req.params.id);
    if (!c) return null;
    c.plan = plan;
    return c;
  });
  if (!result) return res.status(404).json({ error: 'Компания не найдена' });
  res.json({ ok: true });
});

app.post('/api/admin/companies/:id/block', checkAdmin, async (req, res) => {
  const result = await db.update((d) => {
    const c = safeGet(d.companies, req.params.id);
    if (!c) return null;
    c.blocked = !!req.body.blocked;
    return c;
  });
  if (!result) return res.status(404).json({ error: 'Компания не найдена' });
  res.json({ ok: true });
});

app.post('/api/admin/companies/:id/reset-usage', checkAdmin, async (req, res) => {
  const result = await db.update((d) => {
    const c = safeGet(d.companies, req.params.id);
    if (!c) return null;
    c.usage = { submissions: 0 };
    return c;
  });
  if (!result) return res.status(404).json({ error: 'Компания не найдена' });
  res.json({ ok: true });
});

app.delete('/api/admin/companies/:id', checkAdmin, async (req, res) => {
  const cid = req.params.id;
  await db.update((d) => {
    if (!Object.prototype.hasOwnProperty.call(d.companies, cid)) return;
    delete d.companies[cid];
    Object.keys(d.tests).forEach(id => { if (d.tests[id].companyId === cid) delete d.tests[id]; });
    Object.keys(d.sessions).forEach(code => { if (d.sessions[code].companyId === cid) delete d.sessions[code]; });
    Object.keys(d.labs).forEach(id => { if (d.labs[id].companyId === cid) delete d.labs[id]; });
    Object.keys(d.drawingTasks).forEach(id => { if (d.drawingTasks[id].companyId === cid) delete d.drawingTasks[id]; });
  });
  res.json({ ok: true });
});

// Очистка кэша переводов (RU -> KK). Нужна на случай, если ранее (до исправления
// translateOne) в кэш попали «отравленные» записи — оригинальный русский текст,
// сохранённый как перевод из-за временной ошибки/лимита сервиса MyMemory. После очистки
// все тексты переведутся заново при следующем переключении на казахский язык.
app.post('/api/admin/clear-translations', checkAdmin, async (req, res) => {
  let count = 0;
  await db.update((d) => {
    count = Object.keys(d.translations || {}).length;
    d.translations = {};
  });
  res.json({ ok: true, cleared: count });
});

// Резервная копия всей базы данных целиком (компании, тесты, сессии, тренажёры) в виде
// скачиваемого JSON-файла. Доступно только администратору.
app.get('/api/admin/backup', checkAdmin, (req, res) => {
  const data = db.load();
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  res.setHeader('Content-Disposition', `attachment; filename="quiz-b2b-backup-${stamp}.json"`);
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.send(JSON.stringify(data, null, 2));
});

// Восстановление базы данных из файла, скачанного через «Скачать бэкап базы».
// ПОЛНОСТЬЮ заменяет текущие данные — всё, что появилось после создания бэкапа, будет
// потеряно. Собственный лимит на размер тела запроса (бэкап с изображениями в вопросах
// может быть заметно больше, чем стандартный лимит остальных маршрутов).
app.post('/api/admin/restore', checkAdmin, express.json({ limit: '25mb' }), async (req, res) => {
  const incoming = req.body;
  if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming)) {
    return res.status(400).json({ error: 'Файл не похож на корректный бэкап (ожидался JSON-объект)' });
  }
  const looksValid = ['companies', 'tests', 'sessions'].some(
    key => incoming[key] && typeof incoming[key] === 'object' && !Array.isArray(incoming[key])
  );
  if (!looksValid) {
    return res.status(400).json({ error: 'Файл не похож на бэкап этой платформы — не найдены ожидаемые разделы (companies/tests/sessions)' });
  }
  const restored = await db.restore(incoming);
  res.json({
    ok: true,
    companies: Object.keys(restored.companies).length,
    tests: Object.keys(restored.tests).length,
    sessions: Object.keys(restored.sessions).length,
    labs: Object.keys(restored.labs).length,
    drawingTasks: Object.keys(restored.drawingTasks).length
  });
});

async function seedLabs() {
  await db.update((d) => {
    if (!d.labs) d.labs = {};
    SEED_LABS.forEach(l => { d.labs[l.id] = { ...l, shared: true }; });
  });
  console.log(`[labs] Синхронизировано общих тренажёров: ${SEED_LABS.length}`);
}

async function seedDrawingTasks() {
  await db.update((d) => {
    if (!d.drawingTasks) d.drawingTasks = {};
    SEED_DRAWING_TASKS.forEach(t => { d.drawingTasks[t.id] = { ...t, shared: true }; });
  });
  console.log(`[drawing-tasks] Синхронизировано общих заданий: ${SEED_DRAWING_TASKS.length}`);
}

async function seedAnswerKeys() {
  await db.update((d) => {
    if (!d.answerKeys) d.answerKeys = {};
    SEED_ANSWER_KEYS.forEach(k => { d.answerKeys[k.id] = { ...k, shared: true }; });
  });
  console.log(`[answer-keys] Синхронизировано ключей ответов: ${SEED_ANSWER_KEYS.length}`);
}

async function seedToleranceTasks() {
  await db.update((d) => {
    if (!d.toleranceTasks) d.toleranceTasks = {};
    d.toleranceTasks[SEED_TOLERANCE_TASK.id] = { ...SEED_TOLERANCE_TASK, shared: true };
  });
  console.log(`[tolerance-tasks] Синхронизировано заданий по квалитетам: 1 (${SEED_TOLERANCE_TASK.variants.length} вариантов)`);
}

// ==================== АКТ ДЕФЕКТАЦИИ (тренажёры нового формата) ====================
const defectModule = require('./defect-routes')({
  app, db, io, checkAuth, safeGet, nanoid, participantId, QRCode, getBaseUrl,
  joinLimiter, upload, trialBlockedForCompany, incrementSubmissions
});

// ==================== ГЛОБАЛЬНАЯ ОБРАБОТКА ОШИБОК ====================
// Ловит любую ошибку, брошенную (или переданную через next(err)) внутри
// обработчиков маршрутов, чтобы один сбойный запрос не ронял весь процесс.
app.use((err, req, res, next) => {
  console.error('[unhandled route error]', err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: 'Внутренняя ошибка сервера. Попробуйте ещё раз.' });
});

// Последний рубеж: если ошибка всё же произошла вне express (например, в
// таймере или сокет-обработчике), логируем и продолжаем работу вместо краша.
process.on('uncaughtException', (err) => {
  console.error('[uncaughtException] Сервер продолжает работу:', err);
});
process.on('unhandledRejection', (reason) => {
  console.error('[unhandledRejection] Сервер продолжает работу:', reason);
});

async function start() {
  await db.initCache();
  await seedLabs();
  await seedDrawingTasks();
  await seedAnswerKeys();
  await seedToleranceTasks();
  await defectModule.seed();
  server.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('=== Приложение для тестирования запущено ===');
    console.log(`Панель преподавателя: http://localhost:${PORT}`);
    console.log(`Админ-панель: ${getBaseUrl()}/admin`);
    console.log(`Публичный адрес (для QR): ${getBaseUrl()}`);
    console.log('==============================================');
  });
}

start();
